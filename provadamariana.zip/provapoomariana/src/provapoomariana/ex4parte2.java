import java.util.Scanner;

public class PontoPrincipal {

    public static double distanciaEuclidiana(Ponto A, Ponto B) {
        double dx = B.getX() - A.getX();
        double dy = B.getY() - A.getY();
        return Math.sqrt(dx * dx + dy * dy);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite xA: ");
        double xA = sc.nextDouble();
        System.out.print("Digite yA: ");
        double yA = sc.nextDouble();

        System.out.print("Digite xB: ");
        double xB = sc.nextDouble();
        System.out.print("Digite yB: ");
        double yB = sc.nextDouble();

        Ponto A = new Ponto(xA, yA);
        Ponto B = new Ponto(xB, yB);

        double distancia = distanciaEuclidiana(A, B);

        System.out.println("Distância entre " + A + " e " + B + " = " + distancia);

        sc.close();
    }
}
