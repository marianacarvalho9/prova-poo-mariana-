import java.util.Scanner;

public class Ex3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int totalAlunos = 0;
        int aprovados = 0, reprovados = 0, exame = 0;
        double somaMedias = 0;
        double maiorMedia = 0, menorMedia = 10;

        String continuar;

        do {
            System.out.print("Nome do aluno: ");
            String nome = sc.next();

            System.out.print("Nota 1: ");
            double n1 = sc.nextDouble();

            System.out.print("Nota 2: ");
            double n2 = sc.nextDouble();

            double media = (n1 + n2) / 2;
            System.out.println(nome + " obteve média: " + media);

            if (media < 4) {
                System.out.println("Reprovado");
                reprovados++;
            } else if (media < 6) {
                System.out.println("Exame");
                exame++;
            } else {
                System.out.println("Aprovado");
                aprovados++;
            }

            somaMedias += media;
            totalAlunos++;

            if (media > maiorMedia) maiorMedia = media;
            if (media < menorMedia) menorMedia = media;

            System.out.print("Deseja continuar? (s/n): ");
            continuar = sc.next();

        } while (continuar.equalsIgnoreCase("s"));

        double mediaClasse = somaMedias / totalAlunos;

        System.out.println("\nTotal de alunos: " + totalAlunos);
        System.out.println("Aprovados: " + aprovados);
        System.out.println("Reprovados: " + reprovados);
        System.out.println("Exame: " + exame);
        System.out.println("Média da classe: " + mediaClasse);
        System.out.println("Maior média: " + maiorMedia);
        System.out.println("Menor média: " + menorMedia);

        sc.close();
    }
}
