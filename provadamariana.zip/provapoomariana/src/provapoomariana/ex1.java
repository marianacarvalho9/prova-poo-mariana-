public class Ex1 {
    public static void main(String[] args) {
        // Alternativas corretas: I, II e III (todas são verdadeiras)
        System.out.println("Alternativa escolhida: E (I, II e III)");
        System.out.println("Explicação: Todas descrevem corretamente as estruturas de controle de fluxo em algoritmos.");
    }
}
