import java.util.Scanner;

public class Ex2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite x0: ");
        double x0 = sc.nextDouble();
        System.out.print("Digite y0: ");
        double y0 = sc.nextDouble();
        System.out.print("Digite a: ");
        double a = sc.nextDouble();
        System.out.print("Digite b: ");
        double b = sc.nextDouble();
        System.out.print("Digite c: ");
        double c = sc.nextDouble();

        double distancia = Math.abs(a * x0 + b * y0 + c) / Math.sqrt(a * a + b * b);

        System.out.println("A distância é: " + distancia);

        sc.close();
    }
}
