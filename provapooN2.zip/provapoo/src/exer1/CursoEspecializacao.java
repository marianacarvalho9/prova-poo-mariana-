package exer1;

import java.util.ArrayList;

public class CursoEspecializacao extends Curso {

    private boolean latoSensu;
    private double adicionalDiploma; // valor por aluno

    public CursoEspecializacao(int cod, int ch, int sala,
                               String nome, String nomeProfessor,
                               double valorCurso,
                               ArrayList<Aluno> alunos,
                               boolean latoSensu) {
        super(cod, ch, sala, nome, nomeProfessor, valorCurso, alunos);
        this.latoSensu = latoSensu;
    }

    public boolean isLatoSensu() {
        return latoSensu;
    }

    public void setLatoSensu(boolean latoSensu) {
        this.latoSensu = latoSensu;
    }

    public double getAdicionalDiploma() {
        return adicionalDiploma;
    }

    public void setAdicionalDiploma() {
        int qtd = 0;
        if (getAlunos() != null) {
            qtd = getAlunos().size();
        }

        if (qtd <= 10) {
            adicionalDiploma = 25.0;
        } else if (qtd <= 30) {
            adicionalDiploma = 20.0;
        } else {
            adicionalDiploma = 18.0;
        }
    }

    @Override
    public String toString() {
        return super.toString() +
               " | Especialização (latoSensu=" + latoSensu +
               ", adicionalDiploma=" + adicionalDiploma + ")";
    }
}
