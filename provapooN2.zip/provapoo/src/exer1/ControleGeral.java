package exer1;

import java.util.ArrayList;
import java.util.Scanner;

public class ControleGeral {

    private ArrayList<Aluno> listaAlunos = new ArrayList<>();
    private ArrayList<Curso> listaCursos = new ArrayList<>();
    private ArrayList<CursoEspecializacao> listaEsp = new ArrayList<>();
    private ArrayList<CursoMestrado> listaMest = new ArrayList<>();

    private Scanner entrada = new Scanner(System.in);

    public void cadastrarDados() {

        for (int i = 0; i < 2; i++) {
            System.out.println("\nCadastro do aluno " + (i + 1));

            System.out.print("Código: ");
            int cod = Integer.parseInt(entrada.nextLine());

            System.out.print("Idade: ");
            int idade = Integer.parseInt(entrada.nextLine());

            System.out.print("Nome: ");
            String nome = entrada.nextLine();

            String cpf;
            do {
                System.out.print("CPF (11 dígitos): ");
                cpf = entrada.nextLine();
            } while (cpf.length() != 11);

            System.out.print("Endereço: ");
            String end = entrada.nextLine();

            System.out.print("Sexo (F/M): ");
            boolean sexo = entrada.nextLine().equalsIgnoreCase("F");

            double n1, n2, n3;

            do {
                System.out.print("Nota 1: ");
                n1 = Double.parseDouble(entrada.nextLine());
            } while (n1 < 0 || n1 > 10);

            do {
                System.out.print("Nota 2: ");
                n2 = Double.parseDouble(entrada.nextLine());
            } while (n2 < 0 || n2 > 10);

            do {
                System.out.print("Nota 3: ");
                n3 = Double.parseDouble(entrada.nextLine());
            } while (n3 < 0 || n3 > 10);

            Notas notas = new Notas(n1, n2, n3);
            listaAlunos.add(new Aluno(cod, idade, nome, cpf, end, sexo, notas));
        }

        for (int i = 0; i < 2; i++) {
            System.out.println("\nCadastro do curso " + (i + 1));

            System.out.print("Código: ");
            int cod = Integer.parseInt(entrada.nextLine());

            int ch;
            do {
                System.out.print("Carga horária: ");
                ch = Integer.parseInt(entrada.nextLine());
            } while (ch <= 0);

            System.out.print("Sala: ");
            int sala = Integer.parseInt(entrada.nextLine());

            System.out.print("Nome do curso: ");
            String nome = entrada.nextLine();

            System.out.print("Professor: ");
            String prof = entrada.nextLine();

            double valor;
            do {
                System.out.print("Valor: ");
                valor = Double.parseDouble(entrada.nextLine());
            } while (valor <= 0);

            listaCursos.add(new Curso(cod, ch, sala, nome, prof, valor, new ArrayList<>()));
        }

        for (int i = 0; i < 2; i++) {
            System.out.println("\nCadastro Especialização " + (i + 1));

            System.out.print("Código: ");
            int cod = Integer.parseInt(entrada.nextLine());

            int ch;
            do {
                System.out.print("Carga horária: ");
                ch = Integer.parseInt(entrada.nextLine());
            } while (ch <= 0);

            System.out.print("Sala: ");
            int sala = Integer.parseInt(entrada.nextLine());

            System.out.print("Nome curso: ");
            String nome = entrada.nextLine();

            System.out.print("Professor: ");
            String prof = entrada.nextLine();

            double valor;
            do {
                System.out.print("Valor: ");
                valor = Double.parseDouble(entrada.nextLine());
            } while (valor <= 0);

            CursoEspecializacao ce = new CursoEspecializacao(
                cod, ch, sala, nome, prof, valor, new ArrayList<>(), true
            );
            ce.setAdicionalDiploma();
            listaEsp.add(ce);
        }

        for (int i = 0; i < 2; i++) {
            System.out.println("\nCadastro Mestrado " + (i + 1));

            System.out.print("Código: ");
            int cod = Integer.parseInt(entrada.nextLine());

            int ch;
            do {
                System.out.print("Carga horária: ");
                ch = Integer.parseInt(entrada.nextLine());
            } while (ch <= 0);

            System.out.print("Sala: ");
            int sala = Integer.parseInt(entrada.nextLine());

            System.out.print("Nome curso: ");
            String nome = entrada.nextLine();

            System.out.print("Professor: ");
            String prof = entrada.nextLine();

            double valor;
            do {
                System.out.print("Valor: ");
                valor = Double.parseDouble(entrada.nextLine());
            } while (valor <= 0);

            CursoMestrado cm = new CursoMestrado(
                cod, ch, sala, nome, prof, valor, new ArrayList<>(), true
            );
            cm.setAdicionalDiploma();
            listaMest.add(cm);
        }
    }
}
