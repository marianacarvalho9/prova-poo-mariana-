package exer1;

public void procurarCursoPorNome() {

    System.out.print("\nDigite o nome do curso para buscar: ");
    String nomeBusca = entrada.nextLine();

    boolean achou = false;

    for (Curso c : listaCursos) {
        if (c.getNome().equalsIgnoreCase(nomeBusca)) {
            System.out.println("O nome pertence a um Curso.");
            achou = true;
        }
    }

    for (CursoEspecializacao ce : listaEsp) {
        if (ce.getNome().equalsIgnoreCase(nomeBusca)) {
            System.out.println("O nome pertence a um Curso de Especialização.");
            achou = true;
        }
    }

    for (CursoMestrado cm : listaMest) {
        if (cm.getNome().equalsIgnoreCase(nomeBusca)) {
            System.out.println("O nome pertence a um Curso de Mestrado.");
            achou = true;
        }
    }

    if (!achou) {
        System.out.println("Nenhum curso encontrado com esse nome.");
    }
}
