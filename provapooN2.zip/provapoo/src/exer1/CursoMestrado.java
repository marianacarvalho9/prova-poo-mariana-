package exer1;

import java.util.ArrayList;

public class CursoMestrado extends Curso {

    private boolean strictoSensu;
    private double adicionalDiploma; // valor por aluno

    public CursoMestrado(int cod, int ch, int sala,
                         String nome, String nomeProfessor,
                         double valorCurso,
                         ArrayList<Aluno> alunos,
                         boolean strictoSensu) {
        super(cod, ch, sala, nome, nomeProfessor, valorCurso, alunos);
        this.strictoSensu = strictoSensu;
    }

    public boolean isStrictoSensu() {
        return strictoSensu;
    }

    public void setStrictoSensu(boolean strictoSensu) {
        this.strictoSensu = strictoSensu;
    }

    public double getAdicionalDiploma() {
        return adicionalDiploma;
    }

    public void setAdicionalDiploma() {
        int qtd = 0;
        if (getAlunos() != null) {
            qtd = getAlunos().size();
        }

        if (qtd <= 5) {
            adicionalDiploma = 45.0;
        } else if (qtd <= 15) {
            adicionalDiploma = 43.0;
        } else if (qtd <= 30) {
            adicionalDiploma = 40.0;
        } else {
            adicionalDiploma = 36.0;
        }
    }

    @Override
    public String toString() {
        return super.toString() +
               " | Mestrado (strictoSensu=" + strictoSensu +
               ", adicionalDiploma=" + adicionalDiploma + ")";
    }
}

