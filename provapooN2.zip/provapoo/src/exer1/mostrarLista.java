package exer1;

public void mostrarLista() {

    System.out.println("\nQual lista deseja visualizar?");
    System.out.println("1 - Alunos");
    System.out.println("2 - Cursos");
    System.out.println("3 - Cursos de Especialização");
    System.out.println("4 - Cursos de Mestrado");
    System.out.print("Opção: ");

    int opcao = Integer.parseInt(entrada.nextLine());

    if (opcao == 1) {
        for (Aluno a : listaAlunos) {
            System.out.println(a.toString());
        }
    } else if (opcao == 2) {
        for (Curso c : listaCursos) {
            System.out.println(c.toString());
        }
    } else if (opcao == 3) {
        for (CursoEspecializacao ce : listaEsp) {
            System.out.println(ce.toString());
        }
    } else if (opcao == 4) {
        for (CursoMestrado cm : listaMest) {
            System.out.println(cm.toString());
        }
    } else {
        System.out.println("Opção inválida.");
    }
}
