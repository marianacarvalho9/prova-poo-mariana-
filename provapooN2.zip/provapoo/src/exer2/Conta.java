package exer2;

public interface Conta {

    public double getSaldo();

    public void sacar(double valor);

    public void depositar(double valor);
}
