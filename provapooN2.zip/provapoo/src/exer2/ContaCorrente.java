package exer2;

public class ContaCorrente implements Conta {

    private double saldo;

    public ContaCorrente(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    @Override
    public double getSaldo() {
        return saldo;
    }

    @Override
    public void sacar(double valor) {
        double valorComTaxa = valor * 1.20;

        if (valor > 0 && valorComTaxa <= saldo) {
            saldo -= valorComTaxa;
        }
    }

    @Override
    public void depositar(double valor) {
        if (valor > 0) {
            double valorReal = valor * 0.80; // Discontent 20%
            saldo += valorReal;
        }
    }
}
